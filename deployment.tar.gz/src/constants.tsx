// export const URL = "http://127.0.0.1:5100/api"
export const URL = "http://0.0.0.0:8080/api"
// export const URL = "https://godmode-7y6flpzrmq-ue.a.run.app/api"
// export const URL = "https://godmode-preview-7y6flpzrmq-ue.a.run.app/api"
